package com.fit2081.nutritrack

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fit2081.nutritrack.ui.theme.NutriTrackTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NutriTrackTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    WelcomeScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}


@Preview(showBackground = true)
@Composable
fun WelcomeScreen(modifier: Modifier = Modifier){
    val context = LocalContext.current
    Box(modifier = Modifier.fillMaxSize(), contentAlignment =Alignment.Center){
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ){

            Spacer(modifier = Modifier.height(90.dp))

            Text(
                text = "NutriTrack",
                fontSize = 35.sp,
                fontWeight = FontWeight.Bold
            )
            Image(
                painter = painterResource(id = R.drawable.nutritrackinput_logo),
                contentDescription = "NutriTrack Logo",
                modifier = Modifier.size(120.dp)
            )
            Spacer(modifier = Modifier.height(58.dp))

            Text(
                text = "This app provides general health and nutrition information\n" +
                        "for education purposes only. It is not intended as\n" +
                        "medical advice, diagnosis, or treatment. Always consult a" +
                        "qualified healthcare professional before making any\n" +
                        "changes to your diet, exercise, or health regimen.\n " +
                        "Use this app at your own risk.\n " +
                        "If you'd like to an Accredited Practicing Dietitian(APD),\n " +
                        "please visit the Monash Nutrition/Dietetics Clinic\n " +
                        "discounted rates for students):\n" +"https://www.monash.edu/medicicne/scs/nutrition/clinics/nutrition",
                textAlign = TextAlign.Center,
                fontSize = 13.sp,
                fontFamily = FontFamily.SansSerif,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 15.dp)

            )
            Spacer(modifier = Modifier.height(50.dp))
            Button(
                onClick = {context.startActivity(Intent(context, AppLoginScreen::class.java))
                          },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 34.dp, vertical = 10.dp)
                    .height(43.dp),
                shape = RoundedCornerShape(10.dp)
            ){
            Text(text = "Login",
                fontFamily = FontFamily.SansSerif,
                fontSize = 18.sp,

            )
            }
            Spacer(modifier = Modifier.height(32.dp))
            Text(
                text = "Designed by Harsshit Kurani (34917977)",
                fontSize = 11.sp,
                color = Color.DarkGray


            )




        }
    }


}
