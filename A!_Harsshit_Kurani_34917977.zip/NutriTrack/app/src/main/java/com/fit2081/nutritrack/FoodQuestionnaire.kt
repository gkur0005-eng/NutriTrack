package com.fit2081.nutritrack

import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fit2081.nutritrack.ui.theme.FoodQualityScoring
import com.fit2081.nutritrack.ui.theme.NutriTrackTheme
import java.io.InputStreamReader
import java.util.Calendar

class FoodQuestionnaire : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NutriTrackTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    val userId = intent.getStringExtra("USER_ID") ?: ""
                    FoodQuestionnaireScreen(
                        modifier = Modifier.padding(innerPadding),
                        userId = userId
                    )
                }
            }
        }
    }
}


@Composable
fun FoodQuestionnaireScreen(modifier: Modifier = Modifier, userId: String) {
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("NutriTrackPreferences", Context.MODE_PRIVATE)

    // Saving the data for the checkboxes
    var fruits by remember { mutableStateOf(sharedPreferences.getBoolean("fruits_$userId", false)) }
    var vegetables by remember { mutableStateOf(sharedPreferences.getBoolean("vegetables_$userId", false)) }
    var grains by remember { mutableStateOf(sharedPreferences.getBoolean("grains_$userId", false)) }
    var redMeat by remember { mutableStateOf(sharedPreferences.getBoolean("redMeat_$userId", false)) }
    var fish by remember { mutableStateOf(sharedPreferences.getBoolean("fish_$userId", false)) }
    var seafood by remember { mutableStateOf(sharedPreferences.getBoolean("seafood_$userId", false)) }
    var poultry by remember { mutableStateOf(sharedPreferences.getBoolean("poultry_$userId", false)) }
    var eggs by remember { mutableStateOf(sharedPreferences.getBoolean("eggs_$userId", false)) }
    var nutsSeeds by remember { mutableStateOf(sharedPreferences.getBoolean("nutsSeeds_$userId", false)) }

    // Saving the data for the selected Persona
    var selectedPersona by remember {
        mutableStateOf(sharedPreferences.getString("selectedPersona_$userId", "") ?: "")
    }
    var isPersonaDropdownExpanded by remember { mutableStateOf(false) }
    val personas = listOf(
        "Health Devotee", "Mindful Eater", "Wellness Striver",
        "Balance Seeker", "Health Procrastinator", "Food Carefree"
    )

    // Saving data for Timepickers
    var biggestMealTime by remember { mutableStateOf("00:00") }
    var timeofsleep by remember { mutableStateOf("00:00") }
    var awaketime by remember { mutableStateOf("00:00") }

    var showPersonaModal by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {

            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = "Food Intake Questionnaire",
                fontSize = 24.sp,
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(5.dp))

        Text(
            text = "Tick all of the food categories you can eat",
            fontSize = 16.sp,
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = fruits, onCheckedChange = { fruits = it })
                    Text(text = "Fruits", fontSize = 14.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = redMeat, onCheckedChange = { redMeat = it })
                    Text(text = "Red Meat", fontSize = 14.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = fish, onCheckedChange = { fish = it })
                    Text(text = "Fish", fontSize = 14.sp)
                }
            }
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = vegetables, onCheckedChange = { vegetables = it })
                    Text(text = "Vegetables", fontSize = 14.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = seafood, onCheckedChange = { seafood = it })
                    Text(text = "Seafood", fontSize = 14.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = eggs, onCheckedChange = { eggs = it })
                    Text(text = "Eggs", fontSize = 14.sp)
                }
            }
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = grains, onCheckedChange = { grains = it })
                    Text(text = "Grains", fontSize = 14.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = poultry, onCheckedChange = { poultry = it })
                    Text(text = "Poultry", fontSize = 14.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = nutsSeeds, onCheckedChange = { nutsSeeds = it })
                    Text(text = "Nuts/Seeds", fontSize = 14.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(5.dp))

        Text(
            text = "Your Persona",
            fontSize = 16.sp,
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "People can be broadly classified in 6 different types based on their eating preferences. Click on each button to find out the different types, and select the best type that fits you!",
            fontSize = 12.sp,
            fontFamily = FontFamily.SansSerif,
            textAlign = TextAlign.Start,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(5.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = { selectedPersona = "Health Devotee"; showPersonaModal = true },
                modifier = Modifier.weight(1f).padding(1.dp)
            ) {
                Text(text = "Health Devotee", fontSize = 10.sp)
            }
            Button(
                onClick = { selectedPersona = "Mindful Eater"; showPersonaModal = true },
                modifier = Modifier.weight(1f).padding(1.dp)
            ) {
                Text(text = "Mindful Eater", fontSize = 10.sp)
            }
            Button(
                onClick = { selectedPersona = "Wellness Striver"; showPersonaModal = true },
                modifier = Modifier.weight(1f).padding(1.dp)
            ) {
                Text(text = "Wellness Striver", fontSize = 10.sp)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = { selectedPersona = "Balance Seeker"; showPersonaModal = true },
                modifier = Modifier.weight(1f).padding(1.dp)
            ) {
                Text(text = "Balance Seeker", fontSize = 10.sp)
            }
            Button(
                onClick = { selectedPersona = "Health Procrastinator"; showPersonaModal = true },
                modifier = Modifier.weight(1f).padding(1.dp)
            ) {
                Text(text = "Health Procrastinator", fontSize = 10.sp)
            }
            Button(
                onClick = { selectedPersona = "Food Carefree"; showPersonaModal = true },
                modifier = Modifier.weight(1f).padding(1.dp)
            ) {
                Text(text = "Food Carefree", fontSize = 10.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Which persona best fits you?",
            fontSize = 16.sp,
            fontFamily = FontFamily.SansSerif,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = selectedPersona,
            onValueChange = {},
            label = { Text(text = "Select your persona") },
            trailingIcon = {
                IconButton(onClick = { isPersonaDropdownExpanded = true }) {
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Dropdown Persona Types")
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 20.dp),
            shape = RoundedCornerShape(12.dp),
            readOnly = true
        )

        DropdownMenu(
            expanded = isPersonaDropdownExpanded,
            onDismissRequest = { isPersonaDropdownExpanded = false },
            modifier = Modifier.fillMaxWidth()
        ) {
            personas.forEach { persona ->
                DropdownMenuItem(
                    text = { Text(persona) },
                    onClick = {
                        selectedPersona = persona
                        isPersonaDropdownExpanded = false
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Timings",
            fontSize = 16.sp,
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(10.dp))

        TimePickerField(
            label = "What time of day approx. do you normally eat your biggest meal?",
            time = biggestMealTime,
            onTimeChange = { biggestMealTime = it }
        )

        Spacer(modifier = Modifier.height(10.dp))

        TimePickerField(
            label = "What time of day approx. do you go to sleep at night?",
            time = timeofsleep,
            onTimeChange = { timeofsleep = it }
        )

        Spacer(modifier = Modifier.height(10.dp))

        TimePickerField(
            label = "What time of day approx. do you wake up in the morning?",
            time = awaketime,
            onTimeChange = { awaketime = it }
        )

        Spacer(modifier = Modifier.height(15.dp))

        // Implementing the Save button
        Button(
            onClick = {
                // Save user-specific data to SharedPreferences
                with(sharedPreferences.edit()) {
                    putBoolean("fruits_$userId", fruits)
                    putBoolean("vegetables_$userId", vegetables)
                    putBoolean("grains_$userId", grains)
                    putBoolean("redMeat_$userId", redMeat)
                    putBoolean("fish_$userId", fish)
                    putBoolean("seafood_$userId", seafood)
                    putBoolean("poultry_$userId", poultry)
                    putBoolean("eggs_$userId", eggs)
                    putBoolean("nutsSeeds_$userId", nutsSeeds)
                    putString("selectedPersona_$userId", selectedPersona)
                    putString("biggestMealTime_$userId", biggestMealTime)
                    putString("sleepTime_$userId", timeofsleep)
                    putString("wakeUpTime_$userId", awaketime)
                    apply()
                }


                val dataFromCsv = parseCsvData(context, "NutriTrack_csv_data_HK.csv")
                val chosenFoods = mutableListOf<String>().apply {
                    if (fruits) add("Fruits")
                    if (vegetables) add("Vegetables")
                    if (grains) add("Grains")
                    if (redMeat) add("Red Meat")
                    if (fish) add("Fish")
                    if (seafood) add("Seafood")
                    if (poultry) add("Poultry")
                    if (eggs) add("Eggs")
                    if (nutsSeeds) add("Nuts/Seeds")
                }
                val score = computeFoodScore(chosenFoods, selectedPersona, dataFromCsv, userId, "Male")


                val intent = Intent(context, FoodQualityScoring::class.java).apply {
                    putExtra("USER_ID", userId)
                    putExtra("selectedPersona", selectedPersona)
                    putExtra("biggestMealTime", biggestMealTime)
                    putExtra("sleepTime", timeofsleep)
                    putExtra("wakeUpTime", awaketime)
                    putExtra("SELECTED_FOODS", chosenFoods.toTypedArray())
                    putExtra("SCORE", score)
                }
                context.startActivity(intent)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(45.dp)
                .padding(horizontal = 25.dp),
            shape = RoundedCornerShape(6.dp)
        ) {
            Text(text = "Save", fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(10.dp))
    }

    if (showPersonaModal) {
        PersonaModal(
            persona = selectedPersona,
            onDismiss = { showPersonaModal = false }
        )
    }
}

@Composable
fun TimePickerField(
    label: String,
    time: String,
    onTimeChange: (String) -> Unit
) {
    val context = LocalContext.current

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            modifier = Modifier.weight(1f)
        )
        OutlinedButton(
            onClick = {
                val calendar = Calendar.getInstance()
                val hour = calendar.get(Calendar.HOUR_OF_DAY)
                val minute = calendar.get(Calendar.MINUTE)

                TimePickerDialog(
                    context,
                    { _, selectedHour, selectedMinute ->
                        val formattedTime = "${selectedHour.toString().padStart(2, '0')}:${selectedMinute.toString().padStart(2, '0')}"
                        onTimeChange(formattedTime)
                    },
                    hour,
                    minute,
                    true
                ).show()
            },
            modifier = Modifier
                .padding(start = 6.dp)
                .height(32.dp)
        ) {
            Text(
                text = time,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
fun PersonaModal(persona: String, onDismiss: () -> Unit) {
    val personaImage = when (persona) {
        "Health Devotee" -> R.drawable.healthdevotee
        "Mindful Eater" -> R.drawable.mindfuleater
        "Wellness Striver" -> R.drawable.wellness_striver
        "Balance Seeker" -> R.drawable.balanceseeker
        "Health Procrastinator" -> R.drawable.healthprocrastinator
        "Food Carefree" -> R.drawable.foodcarefree
        else -> null
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = persona) },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                personaImage?.let {
                    Image(
                        painter = painterResource(id = it),
                        contentDescription = "$persona Image",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }
                Text(
                    text = when (persona) {
                        "Health Devotee" -> "Health Devotee\n\nI’m passionate about healthy eating & health plays a big part in my life. I use social media to follow active lifestyle personalities or get new recipes/exercise ideas. I may even buy superfoods or follow a particular type of diet. I like to think I am super healthy."
                        "Mindful Eater" -> "Mindful Eater\n\nI’m health-conscious and being healthy and eating healthy is important to me. Although health means different things to different people, I make conscious lifestyle decisions about eating based on what I believe healthy means. I look for new recipes and healthy eating information on social media."
                        "Wellness Striver" -> "Wellness Striver\n\nI aspire to be healthy (but struggle sometimes). Healthy eating is hard work! I’ve tried to improve my diet, but always find things that make it difficult to stick with the changes. Sometimes I notice recipe ideas or healthy eating hacks, and if it seems easy enough, I’ll give it a go."
                        "Balance Seeker" -> "Balance Seeker\n\nI try and live a balanced lifestyle, and I think that all foods are okay in moderation. I shouldn’t have to feel guilty about eating a piece of cake now and again. I get all sorts of inspiration from social media like finding out about new restaurants, fun recipes and sometimes healthy eating tips."
                        "Health Procrastinator" -> "Health Procrastinator\n\nI’m contemplating healthy eating but it’s not a priority for me right now. I know the basics about what it means to be healthy, but it doesn’t seem relevant to me right now. I have taken a few steps to be healthier but I am not motivated to make it a high priority because I have too many other things going on in my life."
                        "Food Carefree" -> "Food Carefree\n\nI’m not bothered about healthy eating. I don’t really see the point and I don’t think about it. I don’t really notice healthy eating tips or recipes and I don’t care what I eat."
                        else -> "Select a Persona"
                    },
                    fontSize = 14.sp,
                    fontFamily = FontFamily.SansSerif,
                    textAlign = TextAlign.Center
                )
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Dismiss", fontSize = 14.sp)
            }
        }
    )
}

fun parseCsvData(context: Context, fileName: String): List<Map<String, String>> {
    val result = mutableListOf<Map<String, String>>()
    try {
        val inputStream = context.assets.open("NutriTrack_csv_data_HK.csv")
        val reader = InputStreamReader(inputStream)
        val lines = reader.readLines()
        val headers = lines[0].split(",").map { it.trim() }

        for (line in lines.drop(1)) { // Skip header row
            val values = line.split(",").map { it.trim() }
            if (values.size >= headers.size) {
                val row = headers.zip(values).toMap()
                result.add(row)
            }
        }
        reader.close()
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return result
}

fun computeFoodScore(
    chosenFoods: List<String>,
    persona: String?,
    dataFromCsv: List<Map<String, String>>,
    userId: String,
    gender: String = "Male"
): Double {
    if (dataFromCsv.isEmpty()) {
        android.util.Log.e("FoodScore", "No CSV data available")
        return 0.0
    }

    // Find the row matching the userId
    val userRow = dataFromCsv.firstOrNull { it["User_ID"] == userId }
    if (userRow == null) {
        android.util.Log.e("FoodScore", "User ID $userId not found in CSV")
        return 0.0
    }

    // Preloading HEIFA score from the CSV based on user sex
    val initialScore = if (gender == "Male") {
        userRow["HEIFAtotalscoreMale"]?.toDoubleOrNull() ?: 0.0
    } else {
        userRow["HEIFAtotalscoreFemale"]?.toDoubleOrNull() ?: 0.0
    }


    val resultScore = initialScore.coerceAtLeast(0.0).coerceAtMost(100.0)
    return resultScore
}