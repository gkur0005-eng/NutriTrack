package com.fit2081.nutritrack.ui.theme

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fit2081.nutritrack.FoodQuestionnaire
import com.fit2081.nutritrack.R

class FoodQualityScoring : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NutriTrackTheme {
                val userId = intent.getStringExtra("USER_ID") ?: ""
                val score = intent.getDoubleExtra("SCORE", 0.0)
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = { MyBottomnavBar(userId = userId) }
                ) { innerPadding ->
                    HomeScreen(
                        modifier = Modifier.padding(innerPadding),
                        userId = userId,
                        foodQualityScore = score
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    userId: String,
    foodQualityScore: Double
) {
    val context = LocalContext.current
    val sharedPrefs = context.getSharedPreferences("LoggedInUser", Context.MODE_PRIVATE)

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(15.dp))

        Text(
            text = "Hello User, $userId",
            fontSize = 24.sp,
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "You've already filled in your Food Intake Questionnaire, but you can change details here:.",
            fontSize = 14.sp,

        )

        Spacer(modifier = Modifier.height(10.dp))
        Button(
            onClick = {
                val intent = Intent(context, FoodQuestionnaire::class.java).apply {
                    putExtra("user_number", userId)
                }
                context.startActivity(intent)


            }
        ) {
            Text(
                text = "Edit",
                fontSize = 14.sp,
                fontFamily = FontFamily.Serif
            )
        }

        Spacer(modifier = Modifier.height(11.dp))

        Image(
            painter = painterResource(id = R.drawable.foodscoreimage),
            contentDescription = "Plate Image",
            modifier = Modifier
                .size(280.dp)
                .padding(16.dp)
        )

        Spacer(modifier = Modifier.height(15.dp))

        Text(
            text = "My Score",
            fontSize = 18.sp,
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(modifier = Modifier.height(5.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Your Food Quality Score",
                fontSize = 16.sp,
                fontFamily = FontFamily.SansSerif
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "${foodQualityScore.toInt()}/100",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "What is the Food Quality Score?",
            fontSize = 16.sp,
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(5.dp))
        Text(
            text = "Your Food Quality Score provides a snapshot of how well your eating patterns align with established food guidelines, helping you identify both strengths and opportunities for improvement in your diet.\n\nThis personalized measurement considers various food groups including vegetables, fruits, whole grains, and proteins to give you practical insights for making healthier food choices.",
            fontSize = 15.sp,
            fontFamily = FontFamily.SansSerif
        )

        Spacer(modifier = Modifier.height(20.dp))
    }
}
//Adding Bottom Navigation
@Composable
fun MyBottomnavBar(userId: String) {
    val context = LocalContext.current

    BottomAppBar(
        modifier = Modifier.height(60.dp),
        content = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = { /* This is the home screen */ },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(Icons.Default.Home, contentDescription = null)
                    }
                    Text(
                        text = "Home",
                        fontSize = 12.sp
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = { val intent = Intent(context, InsightScreen::class.java)
                            intent.putExtra("USER_ID", userId)
                            context.startActivity(intent)

                        },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(Icons.Default.Info, contentDescription = "InsightScreen")
                    }
                    Text(
                        text = "Insights",
                        fontSize = 12.sp,

                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = { /* TODO Navigate to NutriCoach screen(Next assignment) */ },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(Icons.Default.Person, contentDescription = "NutriCoach TBD")
                    }
                    Text(
                        text = "NutriCoach",
                        fontSize = 12.sp,

                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = { /* TODO: Navigate to Settings */ },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings option")
                    }
                    Text(
                        text = "Settings",
                        fontSize = 12.sp

                    )
                }
            }
        }
    )
}