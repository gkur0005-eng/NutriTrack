package com.fit2081.nutritrack

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fit2081.nutritrack.ui.theme.NutriTrackTheme
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader

class AppLoginScreen : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NutriTrackTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    MyLoginscreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun MyLoginscreen(modifier: Modifier = Modifier) {
    var UserId_num by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var isDropdownExpanded by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val UserIds = remember { loadUserIdsfromcsv(context) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Spacer(modifier = Modifier.height(80.dp))

        Text(
            text = "Log In",
            fontSize = 30.sp,
            fontFamily = FontFamily.SansSerif
        )
        Spacer(modifier = Modifier.height(30.dp))
        OutlinedTextField(
            value = UserId_num,
            onValueChange = { UserId_num = it },
            label = {
                Text(text = "My ID (Provided by your Clinician)")
            },
            trailingIcon = {
                IconButton(onClick = { isDropdownExpanded = true }) {
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Dropdown ID Options")
                }
            },
            placeholder = { Text(text = "Enter your ID") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp)
        )

        DropdownMenu(
            expanded = isDropdownExpanded,
            onDismissRequest = { isDropdownExpanded = false },
            modifier = Modifier.fillMaxWidth()
        ) {
            UserIds.forEach { id ->
                DropdownMenuItem(
                    text = { Text(id) },
                    onClick = {
                        UserId_num = id
                        isDropdownExpanded = false
                    }
                )
            }
        }

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text(text = "Phone number") },
            placeholder = { Text(text = "Enter your number") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Please have your ID and phone number handy before continuing",
            fontSize = 15.sp
        )

        Spacer(modifier = Modifier.height(40.dp))

        Button(
            onClick = {
                if (datavalidator(context, phone, UserId_num)) {
                    val intent = Intent(context, FoodQuestionnaire::class.java)
                    intent.putExtra("USER_ID", UserId_num)
                    context.startActivity(intent)

                } else {
                    Toast.makeText(context, "Invalid Credentials: Please ensure ID and Phone Number are correct", Toast.LENGTH_LONG).show()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .padding(vertical = 5.dp),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = "Continue",
                fontSize = 25.sp,
                modifier = Modifier.padding(horizontal = 20.dp)
            )
        }
    }
}
//Parsing the csv data
fun datavalidator(context: Context, phone: String, userId: String): Boolean {
    val assets = context.assets
    return try {
        val inputStream = assets.open("NutriTrack_csv_data_HK.csv")
        val reader = BufferedReader(InputStreamReader(inputStream))
        reader.useLines { lines ->
            lines.drop(1).any { line ->
                val values = line.split(",")
                values.size > 1 && values[0].trim() == phone.trim() && values[1].trim() == userId.trim()
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
        false
    }
}

fun loadUserIdsfromcsv(context: Context): List<String> {
    val IDnum = mutableSetOf<String>()
    try {
        val inputStream = context.assets.open("NutriTrack_csv_data_HK.csv")
        val reader = BufferedReader(InputStreamReader(inputStream))
        reader.useLines { lines ->
            lines.drop(1).forEach { line ->
                val values = line.split(",")
                if (values.size >= 2) {
                    IDnum.add(values[1].trim())
                }
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return IDnum.toList()
}